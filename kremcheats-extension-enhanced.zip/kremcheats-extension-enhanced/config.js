// Configuration for KremCheats Extension
const CONFIG = {
  // Cloudflare Worker URL
  API_URL: 'https://krem-cheats-panel.nopemacroyt.workers.dev',
  
  // Extension settings
  EXTENSION_NAME: 'KremCheats',
  VERSION: '1.1.0',
  
  // Telegram link for buying keys
  TELEGRAM_LINK: 'https://t.me/KremCheats' // UPDATE THIS WITH YOUR TELEGRAM
};

// Make config available globally
if (typeof window !== 'undefined') {
  window.KREMCHEATS_CONFIG = CONFIG;
}
