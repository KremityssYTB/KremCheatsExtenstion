// Content script - Minimal and non-intrusive
// No anti-detection to avoid breaking the game

(function() {
  'use strict';
  
  console.log('[KremCheats] Content script loaded');
  
  // Skip chrome:// and extension pages
  const currentUrl = window.location.href;
  if (currentUrl.startsWith('chrome://') || currentUrl.startsWith('chrome-extension://')) {
    return;
  }
  
  console.log('[KremCheats] Current URL:', currentUrl);
  
  // Request scripts from background
  function requestScripts() {
    console.log('[KremCheats] Requesting scripts...');
    
    chrome.runtime.sendMessage({
      type: 'GET_SCRIPTS_FOR_URL',
      url: currentUrl
    }, (response) => {
      if (chrome.runtime.lastError) {
        console.error('[KremCheats] Runtime error:', chrome.runtime.lastError);
        return;
      }
      
      if (!response || !response.scripts || response.scripts.length === 0) {
        console.log('[KremCheats] No scripts for this page');
        return;
      }
      
      console.log(`[KremCheats] Received ${response.scripts.length} script(s)`);
      
      // Request injection via background
      chrome.runtime.sendMessage({
        type: 'INJECT_SCRIPTS',
        scripts: response.scripts
      }, (injectionResponse) => {
        if (chrome.runtime.lastError) {
          console.error('[KremCheats] Injection error:', chrome.runtime.lastError);
        } else {
          console.log('[KremCheats] Scripts injected successfully');
        }
      });
    });
  }
  
  // Try injection when DOM is ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
      console.log('[KremCheats] DOM loaded');
      setTimeout(requestScripts, 100);
    });
  } else {
    console.log('[KremCheats] DOM already loaded');
    setTimeout(requestScripts, 100);
  }
  
  // Also try when page is fully loaded
  window.addEventListener('load', () => {
    console.log('[KremCheats] Page fully loaded');
  });
  
  console.log('[KremCheats] Content script ready');
  
})();
