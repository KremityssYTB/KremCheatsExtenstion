// Script Wrapper for KremCheats Extension
// This code wraps userscripts to fix DOMContentLoaded timing issues

(function() {
  'use strict';
  
  console.log('[KremCheats] Script wrapper initializing...');
  
  // Store original addEventListener
  const originalAddEventListener = window.addEventListener;
  
  // Override addEventListener to handle DOMContentLoaded
  window.addEventListener = function(type, listener, options) {
    if (type === 'DOMContentLoaded') {
      console.log('[KremCheats] Intercepted DOMContentLoaded listener');
      
      // If document is already loaded, call listener immediately
      if (document.readyState === 'loading') {
        console.log('[KremCheats] Document still loading, adding listener normally');
        originalAddEventListener.call(window, type, listener, options);
      } else {
        console.log('[KremCheats] Document already loaded, calling listener immediately');
        // Call listener immediately
        setTimeout(() => {
          try {
            listener();
          } catch (error) {
            console.error('[KremCheats] Error in DOMContentLoaded listener:', error);
          }
        }, 0);
      }
    } else {
      // For other events, use original addEventListener
      originalAddEventListener.call(window, type, listener, options);
    }
  };
  
  console.log('[KremCheats] Script wrapper ready');
  
})();
