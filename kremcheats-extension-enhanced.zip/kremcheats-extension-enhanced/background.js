// Background service worker for KremCheats FINAL
// FORCE UI TO SHOW NO MATTER WHAT

console.log('[KremCheats] Background script FINAL loaded');

let GM_POLYFILL_CODE = '';

fetch(chrome.runtime.getURL('gm-polyfill.js'))
  .then(response => response.text())
  .then(code => {
    GM_POLYFILL_CODE = code;
    console.log('[KremCheats] GM polyfill loaded');
  })
  .catch(error => {
    console.error('[KremCheats] Failed to load GM polyfill:', error);
  });

function parseRequireDirectives(scriptCode) {
  const requires = [];
  const lines = scriptCode.split('\n');
  
  for (const line of lines) {
    const trimmed = line.trim();
    if (trimmed === '// ==/UserScript==') break;
    
    const requireMatch = trimmed.match(/^\/\/\s*@require\s+(.+)$/);
    if (requireMatch) {
      requires.push(requireMatch[1].trim());
    }
  }
  
  return requires;
}

const libraryCache = new Map();

async function loadExternalLibrary(url) {
  if (libraryCache.has(url)) {
    return libraryCache.get(url);
  }
  
  try {
    const response = await fetch(url);
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    const code = await response.text();
    libraryCache.set(url, code);
    return code;
  } catch (error) {
    console.error('[KremCheats] Failed to load library:', url, error);
    throw error;
  }
}

chrome.runtime.onInstalled.addListener(() => {
  console.log('[KremCheats] Extension installed/updated');
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'SCRIPTS_UPDATED') {
    chrome.tabs.query({}, (tabs) => {
      tabs.forEach(tab => {
        if (tab.url && !tab.url.startsWith('chrome://') && !tab.url.startsWith('chrome-extension://')) {
          chrome.tabs.reload(tab.id);
        }
      });
    });
    sendResponse({ success: true });
    return false;
  }
  
  if (message.type === 'GET_SCRIPTS_FOR_URL') {
    getScriptsForUrl(message.url).then(scripts => {
      sendResponse({ scripts });
    }).catch(error => {
      sendResponse({ scripts: [] });
    });
    return true;
  }
  
  if (message.type === 'INJECT_SCRIPTS') {
    injectScriptsIntoTab(sender.tab.id, message.scripts).then(() => {
      sendResponse({ success: true });
    }).catch(error => {
      sendResponse({ success: false, error: error.message });
    });
    return true;
  }
  
  return false;
});

// FINAL INJECTION - FORCE UI TO SHOW
async function injectScriptsIntoTab(tabId, scripts) {
  try {
    console.log(`[KremCheats] FINAL: Starting injection for tab ${tabId}`);
    
    // Wait for polyfill
    let retries = 0;
    while (!GM_POLYFILL_CODE && retries < 20) {
      await new Promise(resolve => setTimeout(resolve, 50));
      retries++;
    }
    
    if (!GM_POLYFILL_CODE) {
      throw new Error('GM polyfill not loaded');
    }
    
    for (const script of scripts) {
      try {
        console.log(`[KremCheats] FINAL: Processing script: ${script.name}`);
        
        const requireUrls = parseRequireDirectives(script.code);
        
        let fullCode = '';
        
        // 1. GM Polyfill
        fullCode += `
console.log('[KremCheats] FINAL: Loading GM polyfill...');
${GM_POLYFILL_CODE}
console.log('[KremCheats] FINAL: GM polyfill loaded');
`;
        
        // 2. Libraries
        for (const url of requireUrls) {
          try {
            const libraryCode = await loadExternalLibrary(url);
            fullCode += `
console.log('[KremCheats] FINAL: Loading library: ${url}');
${libraryCode}
console.log('[KremCheats] FINAL: Library loaded');
`;
          } catch (error) {
            console.error(`[KremCheats] Failed to load library ${url}:`, error);
          }
        }
        
        // 3. Userscript with FORCED UI INITIALIZATION
        fullCode += `
console.log('[KremCheats] FINAL: ========================================');
console.log('[KremCheats] FINAL: Starting userscript: ${script.name}');
console.log('[KremCheats] FINAL: ========================================');

(function() {
  'use strict';
  
  try {
    // Verify GM functions
    if (typeof GM_getValue !== 'function') {
      throw new Error('GM_getValue not available!');
    }
    console.log('[KremCheats] FINAL: GM functions verified');
    
    // Execute the userscript
    ${script.code}
    
    console.log('[KremCheats] FINAL: Userscript code executed');
    
    // FORCE UI TO SHOW - Multiple strategies
    console.log('[KremCheats] FINAL: Forcing UI initialization...');
    
    // Strategy 1: Call initializeInterface directly if it exists
    if (typeof initializeInterface === 'function') {
      console.log('[KremCheats] FINAL: Found initializeInterface, calling it...');
      try {
        initializeInterface();
        console.log('[KremCheats] FINAL: initializeInterface called successfully');
      } catch (e) {
        console.error('[KremCheats] FINAL: Error calling initializeInterface:', e);
      }
    } else {
      console.log('[KremCheats] FINAL: initializeInterface not found, triggering DOMContentLoaded...');
    }
    
    // Strategy 2: Fire DOMContentLoaded if it hasn't fired
    if (document.readyState === 'loading') {
      console.log('[KremCheats] FINAL: Document still loading, waiting...');
      document.addEventListener('DOMContentLoaded', function() {
        console.log('[KremCheats] FINAL: DOMContentLoaded fired naturally');
      });
    } else {
      console.log('[KremCheats] FINAL: Document already loaded, manually triggering DOMContentLoaded...');
      // Manually fire DOMContentLoaded
      const event = new Event('DOMContentLoaded', { bubbles: true, cancelable: false });
      document.dispatchEvent(event);
      console.log('[KremCheats] FINAL: DOMContentLoaded event dispatched');
    }
    
    // Strategy 3: Check for UI after 1 second
    setTimeout(() => {
      console.log('[KremCheats] FINAL: Checking for UI (1s)...');
      const ui = document.querySelector('.krem-glass-root') || 
                 document.querySelector('.krem-glass-ui') ||
                 document.querySelector('[class*="krem"]');
      
      if (ui) {
        console.log('[KremCheats] FINAL: ✅ UI FOUND:', ui.className);
        console.log('[KremCheats] FINAL: UI visible:', ui.offsetParent !== null);
        console.log('[KremCheats] FINAL: UI display:', window.getComputedStyle(ui).display);
        
        // Make absolutely sure it's visible
        if (ui.offsetParent === null) {
          console.log('[KremCheats] FINAL: UI hidden, forcing visibility...');
          ui.style.display = 'block';
          ui.style.visibility = 'visible';
          ui.style.opacity = '1';
        }
      } else {
        console.error('[KremCheats] FINAL: ❌ UI NOT FOUND');
        console.log('[KremCheats] FINAL: Attempting manual UI creation...');
        
        // Strategy 4: Try to call initializeInterface again
        if (typeof initializeInterface === 'function') {
          try {
            initializeInterface();
            console.log('[KremCheats] FINAL: Manual initializeInterface call succeeded');
          } catch (e) {
            console.error('[KremCheats] FINAL: Manual call failed:', e);
          }
        }
      }
    }, 1000);
    
    // Strategy 5: Add global hotkey to show UI manually (Alt+Shift+K)
    console.log('[KremCheats] FINAL: Adding manual UI trigger (Alt+Shift+K)...');
    document.addEventListener('keydown', function(e) {
      if (e.altKey && e.shiftKey && e.code === 'KeyK') {
        console.log('[KremCheats] FINAL: Manual trigger activated!');
        if (typeof initializeInterface === 'function') {
          initializeInterface();
          console.log('[KremCheats] FINAL: UI manually triggered');
        } else {
          console.error('[KremCheats] FINAL: initializeInterface not available');
        }
      }
    });
    
    console.log('[KremCheats] FINAL: ========================================');
    console.log('[KremCheats] FINAL: Setup complete');
    console.log('[KremCheats] FINAL: If UI not visible, press Alt+Shift+K');
    console.log('[KremCheats] FINAL: ========================================');
    
  } catch (error) {
    console.error('[KremCheats] FINAL: ========================================');
    console.error('[KremCheats] FINAL: CRITICAL ERROR:');
    console.error('[KremCheats] FINAL: Error:', error);
    console.error('[KremCheats] FINAL: Message:', error.message);
    console.error('[KremCheats] FINAL: Stack:', error.stack);
    console.error('[KremCheats] FINAL: ========================================');
  }
})();
`;
        
        console.log(`[KremCheats] FINAL: Injecting complete code...`);
        
        await chrome.scripting.executeScript({
          target: { tabId: tabId },
          world: 'MAIN',
          func: (code) => {
            try {
              (0, eval)(code);
            } catch (error) {
              console.error('[KremCheats] FINAL: Execution error:', error);
            }
          },
          args: [fullCode]
        });
        
        console.log(`[KremCheats] FINAL: Injection complete`);
      } catch (error) {
        console.error(`[KremCheats] FINAL: Failed to inject ${script.name}:`, error);
      }
    }
  } catch (error) {
    console.error('[KremCheats] FINAL: Critical injection error:', error);
    throw error;
  }
}

async function getScriptsForUrl(url) {
  try {
    const storage = await chrome.storage.local.get([
      'kremcheats_authenticated',
      'kremcheats_scripts',
      'kremcheats_enabled_scripts',
      'kremcheats_script_urls',
      'kremcheats_key'
    ]);
    
    if (!storage.kremcheats_authenticated) {
      return [];
    }
    
    const scripts = storage.kremcheats_scripts || [];
    const enabledScripts = storage.kremcheats_enabled_scripts || {};
    const scriptUrls = storage.kremcheats_script_urls || {};
    const key = storage.kremcheats_key;
    
    const matchingScripts = [];
    
    for (const script of scripts) {
      if (enabledScripts[script.id] === false) continue;
      
      const urls = scriptUrls[script.id] || [];
      if (urls.length === 0) continue;
      
      if (urlMatchesPatterns(url, urls)) {
        try {
          const scriptCode = await fetchScriptCode(script.id, key);
          matchingScripts.push({
            id: script.id,
            name: script.name,
            code: scriptCode
          });
        } catch (error) {
          console.error(`[KremCheats] Failed to fetch script:`, error);
        }
      }
    }
    
    return matchingScripts;
  } catch (error) {
    console.error('[KremCheats] Error getting scripts:', error);
    return [];
  }
}

function urlMatchesPatterns(url, patterns) {
  try {
    const urlObj = new URL(url);
    const hostname = urlObj.hostname;
    
    for (const pattern of patterns) {
      const cleanPattern = pattern.replace(/^https?:\/\//, '').replace(/^\/\//, '').trim();
      if (!cleanPattern) continue;
      
      if (cleanPattern.includes('/')) {
        const parts = cleanPattern.split('/');
        const hostPattern = parts[0];
        if (matchHostname(hostname, hostPattern)) return true;
      } else {
        if (matchHostname(hostname, cleanPattern)) return true;
      }
    }
    
    return false;
  } catch (error) {
    return false;
  }
}

function matchHostname(hostname, pattern) {
  if (pattern.startsWith('*.')) {
    const domain = pattern.substring(2);
    return hostname === domain || hostname.endsWith('.' + domain);
  }
  return hostname === pattern;
}

async function fetchScriptCode(scriptId, key) {
  const apiUrl = 'https://krem-cheats-panel.nopemacroyt.workers.dev';
  const response = await fetch(`${apiUrl}/scripts/get?id=${encodeURIComponent(scriptId)}&key=${encodeURIComponent(key)}`);
  
  if (!response.ok) throw new Error(`HTTP ${response.status}`);
  
  const data = await response.json();
  if (!data.success) throw new Error(data.error || 'Failed to fetch script');
  
  return data.code;
}

console.log('[KremCheats] Background script FINAL ready');
