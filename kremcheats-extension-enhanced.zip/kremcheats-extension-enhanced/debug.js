// Debug panel script

async function loadDebugInfo() {
  const storage = await chrome.storage.local.get([
    'kremcheats_authenticated',
    'kremcheats_key',
    'kremcheats_scripts',
    'kremcheats_enabled_scripts',
    'kremcheats_script_urls'
  ]);
  
  // Auth status
  const authEl = document.getElementById('authStatus');
  if (storage.kremcheats_authenticated) {
    authEl.textContent = `✅ Authenticated\nKey: ${storage.kremcheats_key || 'N/A'}`;
  } else {
    authEl.textContent = '❌ Not authenticated';
  }
  
  // Scripts info
  const scriptsEl = document.getElementById('scriptsInfo');
  const scripts = storage.kremcheats_scripts || [];
  if (scripts.length > 0) {
    scriptsEl.textContent = `Total scripts: ${scripts.length}\n\n` +
      scripts.map(s => `ID: ${s.id}\nName: ${s.name}\nDescription: ${s.description || 'N/A'}`).join('\n\n');
  } else {
    scriptsEl.textContent = 'No scripts available';
  }
  
  // Enabled scripts
  const enabledEl = document.getElementById('enabledInfo');
  const enabled = storage.kremcheats_enabled_scripts || {};
  const enabledList = Object.entries(enabled)
    .filter(([id, isEnabled]) => isEnabled !== false)
    .map(([id]) => {
      const script = scripts.find(s => s.id === id);
      return script ? script.name : id;
    });
  
  if (enabledList.length > 0) {
    enabledEl.textContent = enabledList.join('\n');
  } else {
    enabledEl.textContent = 'All scripts enabled by default';
  }
  
  // URL patterns
  const urlsEl = document.getElementById('urlsInfo');
  const urls = storage.kremcheats_script_urls || {};
  if (Object.keys(urls).length > 0) {
    urlsEl.textContent = Object.entries(urls).map(([id, patterns]) => {
      const script = scripts.find(s => s.id === id);
      const name = script ? script.name : id;
      return `${name}:\n  ${patterns.join(', ') || 'No patterns'}`;
    }).join('\n\n');
  } else {
    urlsEl.textContent = 'No URL patterns configured';
  }
}

// Test URL matching
document.getElementById('testBtn').addEventListener('click', async () => {
  const testUrl = document.getElementById('testUrl').value.trim();
  const resultEl = document.getElementById('testResult');
  
  if (!testUrl) {
    resultEl.textContent = 'Please enter a URL';
    return;
  }
  
  resultEl.textContent = 'Testing...';
  
  try {
    // Send message to background script
    chrome.runtime.sendMessage({
      type: 'GET_SCRIPTS_FOR_URL',
      url: testUrl
    }, (response) => {
      if (chrome.runtime.lastError) {
        resultEl.textContent = `Error: ${chrome.runtime.lastError.message}`;
        return;
      }
      
      if (!response) {
        resultEl.textContent = 'No response from background script';
        return;
      }
      
      if (response.scripts && response.scripts.length > 0) {
        resultEl.textContent = `✅ ${response.scripts.length} script(s) would run:\n\n` +
          response.scripts.map(s => `- ${s.name} (${s.code?.length || 0} chars)`).join('\n');
      } else {
        resultEl.textContent = '❌ No scripts match this URL\n\nPossible reasons:\n' +
          '- No URL patterns configured\n' +
          '- URL doesn\'t match any patterns\n' +
          '- Scripts are disabled\n' +
          '- Not authenticated';
      }
    });
  } catch (error) {
    resultEl.textContent = `Error: ${error.message}`;
  }
});

// Refresh data
document.getElementById('refreshBtn').addEventListener('click', () => {
  loadDebugInfo();
});

// Clear storage
document.getElementById('clearBtn').addEventListener('click', async () => {
  if (confirm('Clear all extension data? You will need to login again.')) {
    await chrome.storage.local.clear();
    alert('Storage cleared!');
    loadDebugInfo();
  }
});

// Open console
document.getElementById('consoleBtn').addEventListener('click', () => {
  alert('Press F12 to open the browser console and see detailed logs');
});

// Load on page load
loadDebugInfo();
