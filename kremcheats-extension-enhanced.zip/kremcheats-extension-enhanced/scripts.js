// Initialize particles (same config as login)
particlesJS('particles-js', {
  particles: {
    number: { value: 80, density: { enable: true, value_area: 800 } },
    color: { value: '#00ff00' },
    shape: { type: 'circle' },
    opacity: { value: 0.5 },
    size: { value: 3, random: true },
    line_linked: { enable: true, distance: 150, color: '#00ff00', opacity: 0.4, width: 1 },
    move: { enable: true, speed: 2 }
  },
  interactivity: {
    detect_on: 'canvas',
    events: {
      onhover: { enable: true, mode: 'repulse' },
      onclick: { enable: true, mode: 'push' }
    }
  }
});

// Check authentication and validate key
chrome.storage.local.get(['kremcheats_authenticated', 'kremcheats_key'], async (result) => {
  if (!result.kremcheats_authenticated || !result.kremcheats_key) {
    window.location.href = 'login.html';
    return;
  }
  
  // Validate the key before loading scripts
  try {
    const apiUrl = window.KREMCHEATS_CONFIG.API_URL;
    const response = await fetch(`${apiUrl}/auth?key=${encodeURIComponent(result.kremcheats_key)}`);
    const responseText = await response.text();
    
    if (responseText === 'VALID') {
      // Key is valid, load scripts
      await loadScripts(result.kremcheats_key);
    } else if (responseText === 'EXPIRED') {
      // Key expired, auto-delete and logout
      console.log('[KremCheats] Key expired, logging out...');
      await chrome.storage.local.clear();
      alert('Your key has expired. Please purchase a new key.');
      window.location.href = 'login.html';
    } else {
      // Other error, logout
      console.log('[KremCheats] Key validation failed:', responseText);
      await chrome.storage.local.clear();
      alert('Authentication failed. Please login again.');
      window.location.href = 'login.html';
    }
  } catch (error) {
    console.error('[KremCheats] Error validating key:', error);
    // On network error, allow access (don't logout)
    await loadScripts(result.kremcheats_key);
  }
});

// Load scripts from API using /scripts/list endpoint
async function loadScripts(key) {
  const apiUrl = window.KREMCHEATS_CONFIG.API_URL;
  const contentEl = document.getElementById('scriptsContent');
  
  try {
    const response = await fetch(`${apiUrl}/scripts/list?key=${encodeURIComponent(key)}`, {
      method: 'GET'
    });
    
    if (!response.ok) {
      throw new Error('Failed to load scripts');
    }
    
    const data = await response.json();
    
    if (!data.success) {
      throw new Error(data.error || 'Failed to load scripts');
    }
    
    const scripts = data.scripts || [];
    
    // Get enabled scripts from storage
    const storage = await chrome.storage.local.get(['kremcheats_enabled_scripts', 'kremcheats_script_urls']);
    const enabledScripts = storage.kremcheats_enabled_scripts || {};
    const scriptUrls = storage.kremcheats_script_urls || {};
    
    if (scripts.length === 0) {
      contentEl.innerHTML = `
        <div class="empty-state">
          <h2>No Scripts Available</h2>
          <p>Contact your administrator to add scripts</p>
        </div>
      `;
      return;
    }
    
    // Render scripts list
    contentEl.innerHTML = '<div class="scripts-list"></div>';
    const listEl = contentEl.querySelector('.scripts-list');
    
    for (const script of scripts) {
      const isEnabled = enabledScripts[script.id] !== false; // Default to enabled
      const urls = scriptUrls[script.id] || [];
      
      const scriptEl = document.createElement('div');
      scriptEl.className = 'script-item';
      scriptEl.innerHTML = `
        <div class="script-header">
          <div class="script-name">${escapeHtml(script.name)}</div>
          <div class="script-toggle ${isEnabled ? 'active' : ''}" data-script-id="${script.id}"></div>
        </div>
        ${script.description ? `<div class="script-description">${escapeHtml(script.description)}</div>` : ''}
        <div class="script-url-config">
          <input type="text" 
                 class="url-input" 
                 data-script-id="${script.id}" 
                 placeholder="Enter URL patterns (comma separated): example.com, *.google.com"
                 value="${escapeHtml(urls.join(', '))}">
          <button class="save-url-btn" data-script-id="${script.id}">Save URLs</button>
        </div>
        ${urls.length > 0 ? `
          <div class="script-urls">
            ${urls.map(url => `<span class="url-tag">${escapeHtml(url)}</span>`).join('')}
          </div>
        ` : '<div class="script-urls-empty">No URL patterns configured</div>'}
      `;
      
      listEl.appendChild(scriptEl);
      
      // Add toggle handler
      const toggleEl = scriptEl.querySelector('.script-toggle');
      toggleEl.addEventListener('click', () => toggleScript(script.id, toggleEl));
      
      // Add save URL handler
      const saveBtn = scriptEl.querySelector('.save-url-btn');
      saveBtn.addEventListener('click', () => saveScriptUrls(script.id, scriptEl));
    }
    
    // Store scripts data
    await chrome.storage.local.set({ kremcheats_scripts: scripts });
    
  } catch (error) {
    console.error('Error loading scripts:', error);
    contentEl.innerHTML = `
      <div class="empty-state">
        <h2>Error Loading Scripts</h2>
        <p>${escapeHtml(error.message)}</p>
      </div>
    `;
  }
}

// Save script URLs
async function saveScriptUrls(scriptId, scriptEl) {
  const input = scriptEl.querySelector('.url-input');
  const urlsText = input.value.trim();
  
  // Parse URLs (comma separated)
  const urls = urlsText
    .split(',')
    .map(u => u.trim())
    .filter(u => u.length > 0);
  
  // Save to storage
  const storage = await chrome.storage.local.get(['kremcheats_script_urls']);
  const scriptUrls = storage.kremcheats_script_urls || {};
  scriptUrls[scriptId] = urls;
  await chrome.storage.local.set({ kremcheats_script_urls: scriptUrls });
  
  // Update UI
  const urlsContainer = scriptEl.querySelector('.script-urls, .script-urls-empty');
  if (urls.length > 0) {
    urlsContainer.className = 'script-urls';
    urlsContainer.innerHTML = urls.map(url => `<span class="url-tag">${escapeHtml(url)}</span>`).join('');
  } else {
    urlsContainer.className = 'script-urls-empty';
    urlsContainer.textContent = 'No URL patterns configured';
  }
  
  // Show success feedback
  const saveBtn = scriptEl.querySelector('.save-url-btn');
  const originalText = saveBtn.textContent;
  saveBtn.textContent = '✓ Saved!';
  saveBtn.style.background = 'rgba(0, 255, 0, 0.3)';
  setTimeout(() => {
    saveBtn.textContent = originalText;
    saveBtn.style.background = '';
  }, 2000);
  
  // Notify background script
  chrome.runtime.sendMessage({ type: 'SCRIPTS_UPDATED' });
}

// Toggle script enabled/disabled
async function toggleScript(scriptId, toggleEl) {
  const storage = await chrome.storage.local.get(['kremcheats_enabled_scripts']);
  const enabledScripts = storage.kremcheats_enabled_scripts || {};
  
  // Toggle state
  const isEnabled = !toggleEl.classList.contains('active');
  enabledScripts[scriptId] = isEnabled;
  
  // Update UI
  if (isEnabled) {
    toggleEl.classList.add('active');
  } else {
    toggleEl.classList.remove('active');
  }
  
  // Save to storage
  await chrome.storage.local.set({ kremcheats_enabled_scripts: enabledScripts });
  
  // Notify background script to update content scripts
  chrome.runtime.sendMessage({
    type: 'SCRIPTS_UPDATED'
  });
}

// Logout handler
document.getElementById('logoutBtn').addEventListener('click', async () => {
  await chrome.storage.local.clear();
  window.location.href = 'login.html';
});

// Escape HTML to prevent XSS
function escapeHtml(text) {
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}
