// Check authentication and load scripts
chrome.storage.local.get(['kremcheats_authenticated', 'kremcheats_scripts', 'kremcheats_enabled_scripts'], (result) => {
  const contentEl = document.getElementById('popupContent');
  
  if (!result.kremcheats_authenticated) {
    contentEl.innerHTML = `
      <div class="no-scripts">
        <p>Not authenticated</p>
        <button class="manage-btn" id="openLogin">LOGIN</button>
      </div>
    `;
    document.getElementById('openLogin').addEventListener('click', () => {
      chrome.tabs.create({ url: chrome.runtime.getURL('login.html') });
    });
    return;
  }
  
  const scripts = result.kremcheats_scripts || [];
  const enabledScripts = result.kremcheats_enabled_scripts || {};
  
  if (scripts.length === 0) {
    contentEl.innerHTML = `
      <div class="no-scripts">
        <p>No scripts available</p>
        <button class="manage-btn" id="openScripts">MANAGE SCRIPTS</button>
      </div>
    `;
    document.getElementById('openScripts').addEventListener('click', () => {
      chrome.tabs.create({ url: chrome.runtime.getURL('scripts.html') });
    });
    return;
  }
  
  // Render quick toggles
  let html = '';
  for (const script of scripts) {
    const isEnabled = enabledScripts[script.id] !== false;
    html += `
      <div class="quick-toggle">
        <div class="script-info">
          <div class="script-info-name">${escapeHtml(script.name)}</div>
          <div class="script-info-status">${isEnabled ? 'Active' : 'Disabled'}</div>
        </div>
        <div class="mini-toggle ${isEnabled ? 'active' : ''}" data-script-id="${script.id}"></div>
      </div>
    `;
  }
  
  html += '<button class="manage-btn" id="openScripts">MANAGE SCRIPTS</button>';
  contentEl.innerHTML = html;
  
  // Add toggle handlers
  document.querySelectorAll('.mini-toggle').forEach(toggle => {
    toggle.addEventListener('click', async () => {
      const scriptId = toggle.dataset.scriptId;
      const isEnabled = !toggle.classList.contains('active');
      
      // Update storage
      const storage = await chrome.storage.local.get(['kremcheats_enabled_scripts']);
      const enabled = storage.kremcheats_enabled_scripts || {};
      enabled[scriptId] = isEnabled;
      await chrome.storage.local.set({ kremcheats_enabled_scripts: enabled });
      
      // Update UI
      toggle.classList.toggle('active');
      const statusEl = toggle.parentElement.querySelector('.script-info-status');
      statusEl.textContent = isEnabled ? 'Active' : 'Disabled';
      
      // Notify background
      chrome.runtime.sendMessage({ type: 'SCRIPTS_UPDATED' });
    });
  });
  
  // Open scripts page
  document.getElementById('openScripts').addEventListener('click', () => {
    chrome.tabs.create({ url: chrome.runtime.getURL('scripts.html') });
  });
});

function escapeHtml(text) {
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}
