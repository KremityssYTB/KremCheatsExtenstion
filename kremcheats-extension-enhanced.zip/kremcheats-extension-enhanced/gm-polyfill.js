// GM API Polyfill for KremCheats v4
// Full Tampermonkey & Violentmonkey compatibility with deep merge
(function() {
  'use strict';
  
  // Check if already loaded
  if (window.GM_getValue || window.GM || window.unsafeWindow === window) {
    console.log('[KremCheats] GM API already exists or loaded');
    return;
  }
  
  console.log('[KremCheats] Loading comprehensive GM API polyfill v4...');
  
  const STORAGE_PREFIX = 'kremcheats_gm_';
  
  // ===== Helper: Deep Merge Objects =====
  // This ensures stored configs are merged with new defaults
  function deepMerge(target, source) {
    const output = Object.assign({}, target);
    if (isObject(target) && isObject(source)) {
      Object.keys(source).forEach(key => {
        if (isObject(source[key])) {
          if (!(key in target)) {
            Object.assign(output, { [key]: source[key] });
          } else {
            output[key] = deepMerge(target[key], source[key]);
          }
        } else {
          Object.assign(output, { [key]: source[key] });
        }
      });
    }
    return output;
  }
  
  function isObject(item) {
    return item && typeof item === 'object' && !Array.isArray(item);
  }
  
  // ===== Storage Functions =====
  
  function GM_getValue(key, defaultValue) {
    try {
      const storageKey = STORAGE_PREFIX + key;
      const value = localStorage.getItem(storageKey);
      
      if (value === null || value === undefined) {
        console.log('[KremCheats] GM_getValue: No stored value for', key, '- returning default');
        return defaultValue;
      }
      
      try {
        const parsed = JSON.parse(value);
        
        // If defaultValue is an object and parsed is an object, merge them
        // This ensures new properties in defaultValue are added to old stored configs
        if (isObject(defaultValue) && isObject(parsed)) {
          const merged = deepMerge(defaultValue, parsed);
          console.log('[KremCheats] GM_getValue: Merged stored config with defaults for', key);
          return merged;
        }
        
        return parsed;
      } catch (e) {
        // Not JSON, return as string
        return value;
      }
    } catch (error) {
      console.error('[KremCheats] GM_getValue error:', error);
      return defaultValue;
    }
  }
  
  function GM_setValue(key, value) {
    try {
      const storageKey = STORAGE_PREFIX + key;
      const stringValue = typeof value === 'string' ? value : JSON.stringify(value);
      localStorage.setItem(storageKey, stringValue);
      console.log('[KremCheats] GM_setValue: Saved', key);
      return Promise.resolve();
    } catch (error) {
      console.error('[KremCheats] GM_setValue error:', error);
      return Promise.reject(error);
    }
  }
  
  function GM_deleteValue(key) {
    try {
      const storageKey = STORAGE_PREFIX + key;
      localStorage.removeItem(storageKey);
      console.log('[KremCheats] GM_deleteValue: Deleted', key);
      return Promise.resolve();
    } catch (error) {
      console.error('[KremCheats] GM_deleteValue error:', error);
      return Promise.reject(error);
    }
  }
  
  function GM_listValues() {
    try {
      const keys = [];
      for (let i = 0; i < localStorage.length; i++) {
        const key = localStorage.key(i);
        if (key && key.startsWith(STORAGE_PREFIX)) {
          keys.push(key.substring(STORAGE_PREFIX.length));
        }
      }
      return keys;
    } catch (error) {
      console.error('[KremCheats] GM_listValues error:', error);
      return [];
    }
  }
  
  // ===== DOM Functions =====
  
  function GM_addStyle(css) {
    try {
      const style = document.createElement('style');
      style.type = 'text/css';
      style.textContent = css;
      const head = document.head || document.getElementsByTagName('head')[0] || document.documentElement;
      head.appendChild(style);
      return style;
    } catch (error) {
      console.error('[KremCheats] GM_addStyle error:', error);
      return null;
    }
  }
  
  function GM_addElement(tagName, attributes) {
    try {
      const element = document.createElement(tagName);
      if (attributes) {
        Object.keys(attributes).forEach(key => {
          if (key === 'textContent') {
            element.textContent = attributes[key];
          } else {
            element.setAttribute(key, attributes[key]);
          }
        });
      }
      document.head.appendChild(element);
      return element;
    } catch (error) {
      console.error('[KremCheats] GM_addElement error:', error);
      return null;
    }
  }
  
  // ===== Network Functions =====
  
  function GM_xmlhttpRequest(details) {
    return new Promise((resolve, reject) => {
      try {
        const xhr = new XMLHttpRequest();
        
        xhr.open(details.method || 'GET', details.url, true);
        
        if (details.headers) {
          Object.keys(details.headers).forEach(key => {
            xhr.setRequestHeader(key, details.headers[key]);
          });
        }
        
        if (details.responseType) {
          xhr.responseType = details.responseType;
        }
        
        xhr.onload = function() {
          const response = {
            status: xhr.status,
            statusText: xhr.statusText,
            responseText: xhr.responseText,
            responseHeaders: xhr.getAllResponseHeaders(),
            finalUrl: xhr.responseURL
          };
          
          if (details.onload) details.onload(response);
          resolve(response);
        };
        
        xhr.onerror = function() {
          const error = new Error('Network error');
          if (details.onerror) details.onerror(error);
          reject(error);
        };
        
        xhr.send(details.data || null);
      } catch (error) {
        console.error('[KremCheats] GM_xmlhttpRequest error:', error);
        if (details.onerror) details.onerror(error);
        reject(error);
      }
    });
  }
  
  function GM_download(details) {
    return new Promise((resolve, reject) => {
      try {
        const a = document.createElement('a');
        a.href = details.url;
        a.download = details.name || 'download';
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        resolve();
      } catch (error) {
        console.error('[KremCheats] GM_download error:', error);
        reject(error);
      }
    });
  }
  
  // ===== Window Functions =====
  
  function GM_openInTab(url, options) {
    try {
      const opts = options || {};
      const target = opts.active === false ? '_blank' : '_blank';
      const features = opts.active === false ? 'noopener,noreferrer' : '';
      return window.open(url, target, features);
    } catch (error) {
      console.error('[KremCheats] GM_openInTab error:', error);
      return null;
    }
  }
  
  function GM_setClipboard(text) {
    try {
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(text);
      } else {
        const textarea = document.createElement('textarea');
        textarea.value = text;
        textarea.style.position = 'fixed';
        textarea.style.opacity = '0';
        document.body.appendChild(textarea);
        textarea.select();
        document.execCommand('copy');
        document.body.removeChild(textarea);
      }
    } catch (error) {
      console.error('[KremCheats] GM_setClipboard error:', error);
    }
  }
  
  function GM_notification(details) {
    try {
      if ('Notification' in window) {
        if (Notification.permission === 'granted') {
          new Notification(details.title || 'Notification', {
            body: details.text || '',
            icon: details.image || ''
          });
        } else if (Notification.permission !== 'denied') {
          Notification.requestPermission().then(permission => {
            if (permission === 'granted') {
              new Notification(details.title || 'Notification', {
                body: details.text || '',
                icon: details.image || ''
              });
            }
          });
        }
      }
    } catch (error) {
      console.error('[KremCheats] GM_notification error:', error);
    }
  }
  
  // ===== Menu Functions =====
  
  const menuCommands = new Map();
  let menuCommandId = 0;
  
  function GM_registerMenuCommand(caption, func, accessKey) {
    try {
      const id = ++menuCommandId;
      menuCommands.set(id, { caption, func, accessKey });
      console.log('[KremCheats] Registered menu command:', caption);
      return id;
    } catch (error) {
      console.error('[KremCheats] GM_registerMenuCommand error:', error);
      return null;
    }
  }
  
  function GM_unregisterMenuCommand(id) {
    try {
      menuCommands.delete(id);
      console.log('[KremCheats] Unregistered menu command:', id);
    } catch (error) {
      console.error('[KremCheats] GM_unregisterMenuCommand error:', error);
    }
  }
  
  // ===== Resource Functions =====
  
  const resources = new Map();
  
  function GM_getResourceText(name) {
    try {
      return resources.get(name) || '';
    } catch (error) {
      console.error('[KremCheats] GM_getResourceText error:', error);
      return '';
    }
  }
  
  function GM_getResourceURL(name) {
    try {
      const text = resources.get(name);
      if (!text) return '';
      const blob = new Blob([text], { type: 'text/plain' });
      return URL.createObjectURL(blob);
    } catch (error) {
      console.error('[KremCheats] GM_getResourceURL error:', error);
      return '';
    }
  }
  
  // ===== Info & Context =====
  
  const GM_info = {
    script: {
      name: 'KremCheats Userscript',
      version: '1.0',
      description: 'Running via KremCheats Extension',
      author: 'Unknown'
    },
    scriptMetaStr: '',
    scriptWillUpdate: false,
    scriptHandler: 'KremCheats',
    version: '4.0.0'
  };
  
  const unsafeWindow = window;
  
  // ===== Export to Window =====
  
  // Legacy GM_* functions
  window.GM_getValue = GM_getValue;
  window.GM_setValue = GM_setValue;
  window.GM_deleteValue = GM_deleteValue;
  window.GM_listValues = GM_listValues;
  window.GM_addStyle = GM_addStyle;
  window.GM_addElement = GM_addElement;
  window.GM_xmlhttpRequest = GM_xmlhttpRequest;
  window.GM_download = GM_download;
  window.GM_openInTab = GM_openInTab;
  window.GM_setClipboard = GM_setClipboard;
  window.GM_notification = GM_notification;
  window.GM_registerMenuCommand = GM_registerMenuCommand;
  window.GM_unregisterMenuCommand = GM_unregisterMenuCommand;
  window.GM_getResourceText = GM_getResourceText;
  window.GM_getResourceURL = GM_getResourceURL;
  window.GM_info = GM_info;
  window.unsafeWindow = unsafeWindow;
  
  // Modern GM.* async API
  window.GM = {
    getValue: (key, defaultValue) => Promise.resolve(GM_getValue(key, defaultValue)),
    setValue: GM_setValue,
    deleteValue: GM_deleteValue,
    listValues: () => Promise.resolve(GM_listValues()),
    addStyle: (css) => Promise.resolve(GM_addStyle(css)),
    addElement: (tagName, attributes) => Promise.resolve(GM_addElement(tagName, attributes)),
    xmlHttpRequest: GM_xmlhttpRequest,
    download: GM_download,
    openInTab: (url, options) => Promise.resolve(GM_openInTab(url, options)),
    setClipboard: (text) => Promise.resolve(GM_setClipboard(text)),
    notification: (details) => Promise.resolve(GM_notification(details)),
    registerMenuCommand: (caption, func, accessKey) => Promise.resolve(GM_registerMenuCommand(caption, func, accessKey)),
    unregisterMenuCommand: (id) => Promise.resolve(GM_unregisterMenuCommand(id)),
    getResourceText: (name) => Promise.resolve(GM_getResourceText(name)),
    getResourceUrl: (name) => Promise.resolve(GM_getResourceURL(name)),
    info: GM_info
  };
  
  console.log('[KremCheats] GM API polyfill v4 loaded successfully');
  console.log('[KremCheats] Available APIs:', Object.keys(window).filter(k => k.startsWith('GM')));
  console.log('[KremCheats] Deep merge enabled for config objects');
  
})();
