// Initialize particles
particlesJS('particles-js', {
  particles: {
    number: {
      value: 80,
      density: {
        enable: true,
        value_area: 800
      }
    },
    color: {
      value: '#00ff00'
    },
    shape: {
      type: 'circle',
      stroke: {
        width: 0,
        color: '#000000'
      }
    },
    opacity: {
      value: 0.5,
      random: false,
      anim: {
        enable: false,
        speed: 1,
        opacity_min: 0.1,
        sync: false
      }
    },
    size: {
      value: 3,
      random: true,
      anim: {
        enable: false,
        speed: 40,
        size_min: 0.1,
        sync: false
      }
    },
    line_linked: {
      enable: true,
      distance: 150,
      color: '#00ff00',
      opacity: 0.4,
      width: 1
    },
    move: {
      enable: true,
      speed: 2,
      direction: 'none',
      random: false,
      straight: false,
      out_mode: 'out',
      bounce: false,
      attract: {
        enable: false,
        rotateX: 600,
        rotateY: 1200
      }
    }
  },
  interactivity: {
    detect_on: 'canvas',
    events: {
      onhover: {
        enable: true,
        mode: 'repulse'
      },
      onclick: {
        enable: true,
        mode: 'push'
      },
      resize: true
    },
    modes: {
      grab: {
        distance: 400,
        line_linked: {
          opacity: 1
        }
      },
      bubble: {
        distance: 400,
        size: 40,
        duration: 2,
        opacity: 8,
        speed: 3
      },
      repulse: {
        distance: 100,
        duration: 0.4
      },
      push: {
        particles_nb: 4
      },
      remove: {
        particles_nb: 2
      }
    }
  },
  retina_detect: true
});

// Show status message
function showStatus(message, type) {
  const statusEl = document.getElementById('statusMessage');
  statusEl.textContent = message;
  statusEl.className = 'status-message ' + type;
  
  if (type === 'success') {
    setTimeout(() => {
      statusEl.textContent = '';
      statusEl.className = 'status-message';
    }, 2000);
  }
}

// Validate key with API using /auth endpoint
async function validateKey(key) {
  const apiUrl = window.KREMCHEATS_CONFIG.API_URL;
  
  try {
    const response = await fetch(`${apiUrl}/auth?key=${encodeURIComponent(key)}`, {
      method: 'GET'
    });
    
    const responseText = await response.text();
    
    if (responseText === 'VALID') {
      // Store key in chrome storage
      await chrome.storage.local.set({
        kremcheats_key: key,
        kremcheats_authenticated: true
      });
      
      showStatus('Authentication successful!', 'success');
      
      // Redirect to scripts page
      setTimeout(() => {
        window.location.href = 'scripts.html';
      }, 1000);
    } else {
      // Handle different error types
      let errorMessage = 'Authentication failed';
      
      if (responseText === 'INVALID') {
        errorMessage = 'Invalid key - Please check your key and try again';
      } else if (responseText === 'EXPIRED') {
        errorMessage = 'Key expired - Please purchase a new key';
        // Auto-delete expired key from storage
        await chrome.storage.local.remove(['kremcheats_key', 'kremcheats_authenticated']);
        console.log('[KremCheats] Expired key deleted from storage');
      } else if (responseText === 'IP_LOCKED') {
        errorMessage = 'IP address not authorized - Contact support';
      } else if (responseText === 'DEVICE_LIMIT') {
        errorMessage = 'Maximum device limit reached - Remove a device first';
      } else if (responseText === 'NO_KEY') {
        errorMessage = 'Invalid key format';
      }
      
      showStatus(errorMessage, 'error');
    }
  } catch (error) {
    console.error('Validation error:', error);
    showStatus('Connection error - Please check your internet connection', 'error');
  }
}

// Check if already authenticated and validate key
chrome.storage.local.get(['kremcheats_authenticated', 'kremcheats_key'], async (result) => {
  if (result.kremcheats_authenticated && result.kremcheats_key) {
    // Validate the stored key to ensure it's still valid
    try {
      const apiUrl = window.KREMCHEATS_CONFIG.API_URL;
      const response = await fetch(`${apiUrl}/auth?key=${encodeURIComponent(result.kremcheats_key)}`);
      const responseText = await response.text();
      
      if (responseText === 'VALID') {
        // Key is still valid, redirect to scripts
        window.location.href = 'scripts.html';
      } else if (responseText === 'EXPIRED') {
        // Key expired, auto-delete and logout
        console.log('[KremCheats] Stored key is expired, logging out...');
        await chrome.storage.local.remove(['kremcheats_key', 'kremcheats_authenticated']);
        showStatus('Your key has expired. Please purchase a new key.', 'error');
      } else {
        // Other error (IP_LOCKED, DEVICE_LIMIT, etc.), logout
        console.log('[KremCheats] Key validation failed:', responseText);
        await chrome.storage.local.remove(['kremcheats_key', 'kremcheats_authenticated']);
        showStatus('Authentication failed. Please login again.', 'error');
      }
    } catch (error) {
      console.error('[KremCheats] Error validating stored key:', error);
      // On network error, allow access (don't logout)
      window.location.href = 'scripts.html';
    }
  }
});

// Login button handler
document.getElementById('loginBtn').addEventListener('click', async () => {
  const keyInput = document.getElementById('keyInput');
  const key = keyInput.value.trim();
  
  if (!key) {
    showStatus('Please enter a key', 'error');
    return;
  }
  
  const loginBtn = document.getElementById('loginBtn');
  loginBtn.disabled = true;
  loginBtn.querySelector('.button-text').textContent = 'AUTHENTICATING...';
  
  await validateKey(key);
  
  loginBtn.disabled = false;
  loginBtn.querySelector('.button-text').textContent = 'AUTHENTICATE';
});

// Allow Enter key to submit
document.getElementById('keyInput').addEventListener('keypress', (e) => {
  if (e.key === 'Enter') {
    document.getElementById('loginBtn').click();
  }
});

// Set BUY KEY button link
document.getElementById('buyKeyBtn').addEventListener('click', (e) => {
  e.preventDefault();
  const telegramLink = window.KREMCHEATS_CONFIG.TELEGRAM_LINK;
  window.open(telegramLink, '_blank');
});
